package com.claims.services;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.claims.daos.ClaimDocumentsDao;
import com.claims.daos.ClaimsDao;
import com.claims.models.ClaimDocuments;
import com.claims.models.Claims;

@Service
public class ClaimsService {

	@Autowired ClaimsDao dao;
	@Autowired MemberService mservice;
	@Autowired ClaimDocumentsDao ddao;
	
	public List<Claims> getAllClaims(){		
		return dao.findAll();
	}
	
	public List<Claims> getAllClaimsByMemberName(String name){		
		return dao.findByMemberFnameContains(name);
	}
	
	public List<Claims> getMemberClaims(String memberid){
		return dao.findByMember(mservice.findByMemberId(memberid));
	}
	
	public long totalClaims() {
		return dao.count();
	}
	
	public long totalPending() {
		return dao.findByStatus("Pending").size();
	}
	
	public long totalApproved() {
		return dao.findByStatus("Approved").size();
	}
	
	public Claims findClaimByMemberId(String memberid){
		return dao.findByMemberMemberid(memberid).orElse(null);
	}
	
	public void updateDocs(int claimid,String doc1,String doc2,String doc3) {
		ClaimDocuments cd=new ClaimDocuments();
		cd.setDoc1(doc1);
		cd.setDoc2(doc2);
		cd.setDoc3(doc3);
		cd.setClaim(dao.findById(claimid).get());
		ddao.save(cd);
	}
	
	//add category
	public void saveClaims(Claims c,String member) {
		c.setMember(mservice.findByMemberId(member));
		c.setStatus("Pending");
		dao.save(c);
	}
	
	//UPDATE CLAIM
	public void updateClaims(Claims c) {
		Claims cc = dao.findByMemberMemberid(c.getMember().getMemberid()).get();
		cc.setStatus(c.getStatus());
		cc.setUpdated_on(LocalDateTime.now());
		cc.setUpdatedby(c.getUpdatedby());
		cc.setRej_reason(c.getRej_reason());
		dao.save(cc);
	}
	
}
