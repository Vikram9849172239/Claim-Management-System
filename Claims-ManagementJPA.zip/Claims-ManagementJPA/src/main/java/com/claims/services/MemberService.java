package com.claims.services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.claims.daos.InsuranceDao;
import com.claims.daos.MemberDao;
import com.claims.models.Admin;
import com.claims.models.Insurances;
import com.claims.models.Member;

@Service
public class MemberService {
	@Autowired MemberDao dao;
	@Autowired InsuranceDao idao;

	
	public List<Member> getAllMembers(){		
		return dao.findAll();
	}
	
	//add member
	public String saveMember(Member m) {
		String memberid=generateMemberId();
		m.setMemberid(memberid);
		m.setCreated_on(LocalDateTime.now());
		dao.save(m);
		return memberid;
	}
	
	//get Insurance List
	public List<Insurances> getInsurances(){
		return idao.findAll();
	}
	
	public void createSampleInsurances() {
		Insurances ins1 = new Insurances("Home Insurance",200000,91);
		Insurances ins2 = new Insurances("Life Insurance",1000000,100);
		Insurances ins3 = new Insurances("Vehicle Insurance",100000,80);
		if(idao.count()==0) {
			idao.save(ins1);
			idao.save(ins2);
			idao.save(ins3);
		}
	}
	
	//get Insurance List	
	public Insurances getInsurancesById(int id){
		Insurances ins = idao.findById(id).get();
		ins.setMax_claim_amount(ins.getInsurance_amount()*ins.getPercentage()/100);
		return ins;
	}
	
	//update member
	public void updateMember(Member m) {
		Member mm = findByMemberId(m.getMemberid());
		m.setCreatedby(mm.getCreatedby());
		m.setCreated_on(mm.getCreated_on());
		m.setUpdated_on(LocalDateTime.now());
		dao.save(m);
	}
	
	public Member findByMemberId(String memberid) {
		return dao.findById(memberid).get();				
	}
	
	public String generateMemberId() {
		return String.format("MBC-%05d", totalMembers()+1);
	}
	
	public long totalMembers() {
		return dao.count();
	}
	
}
