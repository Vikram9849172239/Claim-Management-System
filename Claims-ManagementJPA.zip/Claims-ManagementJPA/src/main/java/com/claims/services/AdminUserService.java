package com.claims.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.claims.daos.AdminDao;
import com.claims.models.Admin;

@Service
public class AdminUserService {

	@Autowired NamedParameterJdbcTemplate temp;
	@Autowired AdminDao dao;
	
	public Admin validate(String userid,String pwd) {
		Optional<Admin> admin = dao.findById(userid);
		if(admin.isPresent() && admin.get().getPwd().equals(pwd)) {
			return admin.get();
		}
		return null;
	}
	
	public void createAdmin(Admin admin) {
		if(dao.count()==0) {
			dao.save(admin);
		}
	}
	
	
}
