package com.claims.models;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Claims {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@ManyToOne
	@JoinColumn(name="member_id")
	private Member member;
	private LocalDate req_date;
	private LocalDate process_date;
	private String reason;
	private int final_amount;
	private String status;
	private String rej_reason;
	private LocalDateTime created_on;
	private String createdby;
	private String updatedby;
	private LocalDateTime updated_on;
	
	
	public LocalDateTime getCreated_on() {
		return created_on;
	}
	public void setCreated_on(LocalDateTime created_on) {
		this.created_on = created_on;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public String getUpdatedby() {
		return updatedby;
	}
	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}
	public LocalDateTime getUpdated_on() {
		return updated_on;
	}
	public void setUpdated_on(LocalDateTime updated_on) {
		this.updated_on = updated_on;
	}
	public String getRej_reason() {
		return rej_reason;
	}
	public void setRej_reason(String rej_reason) {
		this.rej_reason = rej_reason;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Member getMember() {
		return member;
	}
	public void setMember(Member member) {
		this.member = member;
	}
	public void setReq_date(LocalDate req_date) {
		this.req_date = req_date;
	}
	public LocalDate getProcess_date() {
		return process_date;
	}
	public void setProcess_date(LocalDate process_date) {
		this.process_date = process_date;
	}
	public LocalDate getReq_date() {
		return req_date;
	}
	public void setReq_date(String req_date) {
		this.req_date = LocalDate.parse(req_date);
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public int getFinal_amount() {
		return final_amount;
	}
	public void setFinal_amount(int final_amount) {
		this.final_amount = final_amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Claims [id=" + id + ", member_id=" + member + ", req_date=" + req_date + ", reason=" + reason
				+ ", final_amount=" + final_amount + ", status=" + status + "]";
	}
	
	

}
