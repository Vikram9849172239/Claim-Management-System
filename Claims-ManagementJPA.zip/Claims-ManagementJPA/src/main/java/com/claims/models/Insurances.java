package com.claims.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Insurances {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String insurance_type;
	private int insurance_amount;
	private int percentage;
	private int max_claim_amount;
	
	public Insurances(String insurance_type, int insurance_amount, int percentage) {
		super();
		this.insurance_type = insurance_type;
		this.insurance_amount = insurance_amount;
		this.percentage = percentage;
	}
	public Insurances() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMax_claim_amount() {
		return max_claim_amount;
	}
	public void setMax_claim_amount(int max_claim_amount) {
		this.max_claim_amount = max_claim_amount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getInsurance_type() {
		return insurance_type;
	}
	public void setInsurance_type(String insurance_type) {
		this.insurance_type = insurance_type;
	}
	public int getInsurance_amount() {
		return insurance_amount;
	}
	public void setInsurance_amount(int insurance_amount) {
		this.insurance_amount = insurance_amount;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	@Override
	public String toString() {
		return "Insurances [insurance_type=" + insurance_type + ", insurance_amount=" + insurance_amount + ", percentage="
				+ percentage + "]";
	}


}
