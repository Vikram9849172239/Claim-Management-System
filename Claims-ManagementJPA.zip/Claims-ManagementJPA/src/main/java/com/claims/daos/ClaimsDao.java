package com.claims.daos;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.claims.models.Claims;
import com.claims.models.Member;

@Repository
public interface ClaimsDao extends JpaRepository<Claims, Integer> {

	List<Claims> findByStatus(String status);
	List<Claims> findByMember(Member member);
	List<Claims> findByMemberFnameContains(String name);
	Optional<Claims> findByMemberMemberid(String id);
}
