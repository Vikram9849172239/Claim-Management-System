package com.claims.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.claims.models.Insurances;

@Repository
public interface InsuranceDao extends JpaRepository<Insurances, Integer> {

}
