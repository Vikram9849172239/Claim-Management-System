package com.claims.daos;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.claims.models.Member;

@Repository
public interface MemberDao extends JpaRepository<Member, String> {
	Optional<Member> findByEmail(String email);
}
