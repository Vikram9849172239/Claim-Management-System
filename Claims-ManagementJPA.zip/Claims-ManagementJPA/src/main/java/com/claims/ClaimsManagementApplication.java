package com.claims;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.claims.daos.InsuranceDao;
import com.claims.models.Admin;
import com.claims.services.AdminUserService;
import com.claims.services.MemberService;

@SpringBootApplication
public class ClaimsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaimsManagementApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner demo(AdminUserService srv, MemberService msrv) {
	    return (args) -> {
	    	Admin admin = new Admin();
	    	admin.setUserid("admin");
	    	admin.setUname("Administartor");
	    	admin.setPwd("admin");
    		srv.createAdmin(admin);
    		msrv.createSampleInsurances();
	    };
	}

}
