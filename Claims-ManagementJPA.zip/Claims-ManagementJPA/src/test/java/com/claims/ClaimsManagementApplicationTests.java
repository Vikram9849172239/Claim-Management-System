package com.claims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimsManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
